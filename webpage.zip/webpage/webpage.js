 $('#startbutton').click(function(){
 	$('#front').addClass('hidden');
 });

//rock-paper-scissor
var userPick = '';
var compPick = '';

$('.user-choice').click(function() {
	$('#outcome').text('');
	userPick = $(this).val();
	var userFull = ('You picked ' + userPick + '!');
	$('#outcome').append( userFull + '<br>' );

	comp();
	whoWon();
});

function comp() {	
	randPick = Math.random();
	if (randPick > 0 && randPick < 0.333) {
		compPick = 'Rock';
	} else if (randPick >= 0.333 && randPick < 0.666) {
		compPick = 'Paper';
	} else if (randPick >= 0.666 && randPick < 1) {
		compPick = 'Scissor';
	}
	var compOutput = ('Bot threw out ' + compPick + '!');
	$('#outcome').append( compOutput + '<br>');
}

function whoWon() {
	if(userPick == 'Rock' && compPick == 'Scissor') {
		$('#outcome').append('You Win!<br>');
	} else if (userPick == 'Paper' && compPick == 'Rock') {
		$('#outcome').append('You Win!<br>');
	} else if (userPick == 'Scissor' && compPick == 'Paper') {
		$('#outcome').append('You Win!<br>');
	} else if (userPick == compPick) {
		$('#outcome').append('Tie!<br>');
	} else {
		$('#outcome').append('You Lose!<br>');
	}

}

//chopstick

var botLeftFingers = 1;
var botRightFingers = 1;
var botTotalFingers = botLeftFingers + botRightFingers;
var userLeftFingers = 1;
var userRightFingers = 1;
var userTotalFingers = userLeftFingers + userRightFingers;
var attacked = '';
var attacker = '';

fingers();

fingers();


$('#confirmButton').click(function() {
	attacked = $('input[name="attacked"]:checked').val();
	attacker = $('input[name="attacker"]:checked').val();
	damageTaken();
	botTurn();	
	fingers();
	if (userLeftFingers >= 5) {
		userLeftFingers = 0;
	} else if ( userRightFingers >=5 ) {
		userRightFingers = 0;
	} else if (botLeftFingers >=5) {
		botLeftFingers = 0;	
	} else if (botRightFingers >=5) {
		botRightFingers = 0;
	} else {
	}
	fingers();
});

if(userLeftFingers == 0 && userRightFingers == 0) {
	$('#csOutcome').text('You lost.');
} else if (botLeftFingers == 0 && botRightFingers == 0) {
	$('#csOutcome').text('You win.');
}

function fingers() {
	$('#botLeft').text('left hand has ' + botLeftFingers + ' finger(s) up');
	$('#botRight').text('Right hand has ' + botRightFingers + ' finger(s) up.');
	$('#userLeft').text('Left hand has ' + userLeftFingers + ' finger(s) up.');
	$('#userRight').text('Right hand has ' + userRightFingers + ' finger(s) up.');
}

function damageTaken() {
	if (attacked == 'botLeft' && attacker == 'userRight') {
		botLeftFingers = userRightFingers + botLeftFingers;
	} else if (attacked == 'botLeft' && attacker == 'userLeft') {
		botLeftFingers = userLeftFingers + botLeftFingers;
	} else if (attacked == 'botRight' && attacker == 'userRight') {
		botRightFingers = userRightFingers + botRightFingers;
	} else if (attacked == 'botRight' && attacker == 'userLeft') {
		botRightFingers = userLeftFingers + botRightFingers;
	}
	fingers();
}

function botTurn() {
	if ((botLeftFingers + userLeftFingers) == 5){
		userLeftFingers = 0;
	} else if ((botLeftFingers + userRightFingers) == 5) {
		userRightFingers = 0;
	} else if ((botRightFingers + userLeftFingers) == 5) {
		userLeftFingers = 0;
	} else if ((botRightFingers + userRightFingers) == 5) {
		userRightFingers = 0;
	} else {
		randomAttack();
	}
	fingers();
}

function randomAttack() {
	var rand = Math.random();
	if(rand >= 0.00 && rand < 0.25) {
		userRightFingers = userRightFingers + botRightFingers;
	} else if(rand >= 0.25 && rand < 0.50) {
		userRightFingers = userRightFingers + botLeftFingers;
	} else if(rand >= 0.50 && rand < 0.75) {
		userLeftFingers = userLeftFingers + botRightFingers;
	} else if(rand >= 0.75 && rand < 1.00) {
		userLeftFingers = userLeftFingers +botLeftFingers;
	}
	fingers();
}